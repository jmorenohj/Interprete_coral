package models

data class ExceptionInter (override val message:String) :Exception(message)